import sys
from rmq_params import *
import pika
from bluetooth import *

def callback(ch, method, properties, body):
	message=str(body,"utf-8")
	if "submitted" in message:
		print("[Checkpoint] Order Update: Your order has been submitted.")
	if"started" in message:
		print("[Checkpoint] Order Update: We are processing your order.")
	if "finished" in message:
		print("[Checkpoint] Order Update: We finished processing your order.")
		connection.close()
		

if __name__=='__main__':
	port=3
	if len(sys.argv)!=5:
		print('[ERROR] Arguments missing or are incorrect')
		print("[ERROR] Closing")
		sys.exit(1)
	RMQ_IP=sys.argv[2]
	BT_ADDR=sys.argv[4]
	host=BT_ADDR
	firsttime=True

	print("[Checkpoint] Connecting to server on %r" %BT_ADDR)
	
	try:
		client_socket=0
		client_socket=BluetoothSocket( RFCOMM )
		client_socket.connect((host, port))
	except:
		print("[ERROR] Unable to open the socket")
		print("[ERROR] Bluetooth socket CLOSING")
		if client_socket:
			client_socket.close()
		exit(1)
	print("[Checkpoint] Connected")

	####receive menu
	try:
		text=client_socket.recv(1024)
		print("[Checkpoint] Received menu:")
		menu=eval(text)

		mymenu = []
		myorder = []
		
		for x in menu:
			print(x,":")
			for y in menu[x]:
				print("     ",y,":",menu[x][y])
		
		#print(menu)

		order = ''


		order = input('Enter items separated by space characters:\n')
		stringorder=str(order)
		myorder = order.split()
		stringmyorder=str(myorder)

				# sending
		client_socket.send(stringmyorder)

		print("[Checkpoint] Sent order:")
		print(myorder)
		###send order


		###receive receipt
		print("[Checkpoint] Received receipt:")
		receipt=eval(str(client_socket.recv(1024),'utf-8'))
		
		print ("Order ID",":",receipt.get("Order ID"))
		print ("Items",":",receipt.get("Items"))
		print ("Total Price",":",receipt.get("Total Price"))  
		print ("Total Time",":",receipt.get("Total Time"))
			

		
		queueid=str(receipt.get('Order ID'))
	
	except:
		print("[ERROR] Communicaiton with the Server Lost or the client.py process was killed")
		print("[ERROR] Bluetooth Socket Closed")
		client_socket.close()
		exit(1)

	print('[Checkpoint] Closed Bluetooth Connection.')

	client_socket.close()


	try:
		connection=0
		credentials = pika.PlainCredentials(username=rmq_params.get("username"),password=rmq_params.get("password"))
		parameters = pika.ConnectionParameters(host=RMQ_IP, virtual_host=rmq_params.get("vhost"), credentials=credentials)
		print("[Checkpoint] Connected to vhost %s on RMQ server at %s as user %s" %(rmq_params.get("vhost"),RMQ_IP,rmq_params.get("username")))
		connection = pika.BlockingConnection(parameters)
		channel = connection.channel()
	except:
		print("[ERROR] Unable to connect to vhost %s on RMQ server at %s as user %s" %(rmq_params.get("vhost"),RMQ_IP,rmq_params.get("username")))
		print("[ERROR] Verify that vhost is up, credentials are correct or the vhost name is correct")
		print("[ERROR] Connection Closing")
		if connection:
			connection.close()
		exit(1)
	try:
		print("[Checkpoint] Consuming from RMQ queue:%s"%queueid)
		channel.basic_consume(callback,queue=queueid,no_ack=True)
		channel.start_consuming()
	except:
		print("[ERROR] The processing queue for the order was not found or the client.py process was killed")
		print("[ERROR] Verify that the processing queue is up. You may have to restart the server")
		print("[ERROR] Connection Closing")
		connection.close()
		exit(1)
		
	


