import pika
import time
import sys
from rmq_params import *					



def callback(ch, method, properties, body):
	
    channel.basic_publish(exchange=rmq_params.get("exchange"),
                      routing_key=rmq_params.get("led_queue"),
                      body="purple")

    receipt = eval(body)
    
                      
    order_id = str(receipt.get("Order ID"))   
    print ("[Checkpoint] Starting order:", order_id)
    
    channel.basic_publish(exchange=rmq_params.get("exchange"),   
                      routing_key=order_id,
                      body="The order it placed has started processing.")
    
    channel.basic_publish(exchange=rmq_params.get("exchange"),
                      routing_key=rmq_params.get("led_queue"),
                      body="yellow")
    
    
    total_time = receipt.get("Total Time")
    real_total_time = int(total_time)
    time.sleep(real_total_time)
    print ("[Checkpoint] Completed order:", order_id)

    
    
    channel.basic_publish(exchange=rmq_params.get("exchange"),     
                      routing_key=order_id,
                      body="The order it placed has finished processing.")

    
    channel.basic_publish(exchange=rmq_params.get("exchange"),
                      routing_key=rmq_params.get("led_queue"),
                      body="green")
    


if __name__== '__main__':		
    
    try:
        credentials = pika.PlainCredentials(username=rmq_params.get("username"),password=rmq_params.get("password"))
        parameters = pika.ConnectionParameters(host=sys.argv[2],virtual_host=rmq_params.get("vhost"),credentials=credentials)
        connection = pika.BlockingConnection(parameters)
        channel = connection.channel()
        print("[Checkpoint] Connected to vhost", rmq_params.get("vhost"), "on RMQ server at", (sys.argv[2]), "as user ", rmq_params.get("username"))


        
    except:
        print("[ERROR] Verify that vhost is up, credentials are correct or the vhost name is correct")
        print("[ERROR] Connection closing")

        if connection:
            connection.close()
        exit(1)	
	
    try:
        channel.basic_consume(callback, queue=rmq_params.get("order_queue"), no_ack=True)
        print("[Checkpoint] Consuming from RMQ queue:", rmq_params.get("order_queue"))
        channel.start_consuming()
	
    except:
        print("[ERROR] Fail to connect")

        if connection:
            connection.close()
        exit(1)	



#    channel.queue_bind(exchange=rmq_params.get("exchange"),
#                       queue=rmq_params.get("order_queue"),
#                       routing_key=rmq_params.get("order_queue"))

